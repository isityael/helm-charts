{{- /*
Copyright 2024-2025 New Vector Ltd
Copyright 2025-2026 Element Creations Ltd

SPDX-License-Identifier: AGPL-3.0-only
*/ -}}

{{- $root := .root -}}
{{- with required "well-known/partial-haproxy.cfg.tpl missing context" .context -}}

frontend well-known-in
{{- if has $root.Values.networking.ipFamily (list "ipv4" "dual-stack") }}
  bind *:8010
{{- end }}
{{- if has $root.Values.networking.ipFamily (list "ipv6" "dual-stack") }}
  bind [::]:8010 {{ (eq $root.Values.networking.ipFamily "dual-stack") | ternary "v6only" "v4v6" }}
{{- end }}

  # same as http log, with %Th (handshake time)
  log-format "%ci:%cp [%tr] %ft %b/%s %Th/%TR/%Tw/%Tc/%Tr/%Ta %ST %B %CC %CS %tsc %ac/%fc/%bc/%sc/%rc %sq/%bq %hr %hs %{+Q}r"

  http-request capture hdr(host) len 32
  http-request capture req.fhdr(x-forwarded-for) len 64
  http-request capture req.fhdr(user-agent) len 200

  acl is_delete_put_post_method method DELETE POST PUT
  http-request deny status 405 if is_delete_put_post_method

  acl well-known path /.well-known/matrix/server
  acl well-known path /.well-known/matrix/client
  acl well-known path /.well-known/matrix/support

{{ if .baseDomainRedirect.enabled }}
{{- if .baseDomainRedirect.url }}
  http-request redirect  code 301  location {{ .baseDomainRedirect.url }} unless well-known
{{- else if $root.Values.elementWeb.enabled }}
{{- with $root.Values.elementWeb }}
{{- $elementWebHttps := include "element-io.ess-library.ingress.tlsHostsSecret" (dict "root" $root "context" (dict "hosts" (list .ingress.host) "tlsSecret" .ingress.tlsSecret "ingressName" "element-web")) }}
  http-request redirect  code 301  location http{{ if $elementWebHttps }}s{{ end }}://{{ tpl .ingress.host $root }} unless well-known
{{- end }}
{{- end }}
{{- end }}

  use_backend well-known-static if well-known
  default_backend well-known-no-match

backend well-known-static
  mode http

{{- range $name, $value := .headers }}
  http-after-response set-header {{ $name }} {{ $value | quote }}
{{- end }}

  http-request return status 200 content-type "application/json" file "/well-known/server" if { path /.well-known/matrix/server }
  http-request return status 200 content-type "application/json" file "/well-known/client" if { path /.well-known/matrix/client }
  http-request return status 200 content-type "application/json" file "/well-known/support" if { path /.well-known/matrix/support }

backend well-known-no-match
  mode http

  http-request deny status 404

{{- end -}}
